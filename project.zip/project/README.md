# ios101-lab6-flix-starter

## iOS 101: Lab - Unit 6 - Flix Pt 2 (Detail)
